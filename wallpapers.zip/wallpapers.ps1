# 1. Define the folder where your wallpapers are stored (Change this path!)
$WallpaperFolder = "D:\wallpapers"

# 2. Get a random image file from the folder (.jpg, .jpeg, or .png)
$RandomFile = Get-ChildItem -Path $WallpaperFolder -Include *.jpg, *.jpeg, *.png -Recurse | Get-Random

if ($RandomFile) {
    $WallpaperPath = $RandomFile.FullName
    Write-Host "Setting wallpaper to: $WallpaperPath"

    # 3. Use Windows API (user32.dll) to force an immediate desktop refresh
    $Signature = @"
    using System.Runtime.InteropServices;
    public class Wallpaper {
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
    }
"@

    # Add the C# type definition to the session if it doesn't already exist
    if (-not ([System.Management.Automation.PSTypeName]'Wallpaper').Type) {
        Add-Type -TypeDefinition $Signature
    }

    # Action flags for setting the wallpaper and broadcasting the change
    $SPI_SETDESKWALLPAPER = 0x0014
    $SPIF_UPDATEINIFILE   = 0x01
    $SPIF_SENDCHANGE      = 0x02

    # Apply the wallpaper
    [Wallpaper]::SystemParametersInfo($SPI_SETDESKWALLPAPER, 0, $WallpaperPath, ($SPIF_UPDATEINIFILE -bor $SPIF_SENDCHANGE))
} else {
    Write-Warning "No valid image files found in the specified folder."
}